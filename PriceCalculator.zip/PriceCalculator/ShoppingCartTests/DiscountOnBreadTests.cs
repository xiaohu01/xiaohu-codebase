﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ShoppingCart;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart.Tests
{
    [TestClass()]
    public class DiscountOnBreadTests
    {
        [TestMethod()]
        public void ApplyTest()
        {
            IBasket basket = new Basket();
            string[] items = new string[] { "Bread", "Milk", "Bean", "Apple", "Bean", "Bread", "Milk" };
            basket.Add(items);

            IDiscount discount = new DiscountOnBread { DiscountRate = 0.5M, OnItem = "Bread" };

            decimal disc = discount.Apply(basket.Items);

            Assert.AreEqual(0.4M, disc);
        }
    }
}