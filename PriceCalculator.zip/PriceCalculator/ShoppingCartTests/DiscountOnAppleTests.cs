﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ShoppingCart;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart.Tests
{
    [TestClass()]
    public class DiscountOnAppleTests
    {
        [TestMethod()]
        public void ApplyTest()
        {
            IDiscount discount = new DiscountOnApple { DiscountRate = 0.1M, OnItem = "Apple", ValidFrom = DateTime.Parse("2021-02-08"), ValidTo = DateTime.Parse("2021-02-15") };

            IBasket basket = new Basket();
            string[] items = new string[] { "Bread", "Milk", "Bean", "Apple", "Bean", "Bread", "Milk" };
            basket.Add(items);

            decimal disc = discount.Apply(basket.Items);

            Assert.AreEqual(0.1M, disc);
        }
    }
}