﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ShoppingCart;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart.Tests
{
    [TestClass()]
    public class BasketTests
    {
        [TestMethod()]
        public void AddTest()
        {
            IBasket basket = new Basket();
            string[] items = new string[] { "Bread", "Milk", "Bean", "Apple", "Bean", "Bread", "Milk" };

            basket.Add(items);

            Assert.AreEqual(2, basket.Items["Bread"]);
            Assert.AreEqual(2, basket.Items["Milk"]);
            Assert.AreEqual(2, basket.Items["Bean"]);
            Assert.AreEqual(1, basket.Items["Apple"]);
        }

        [TestMethod()]
        public void RemoveTest()
        {
            IBasket basket = new Basket();
            string[] items = new string[] { "Bread", "Milk", "Bean", "Apple", "Bean", "Bread", "Milk" };

            basket.Add(items);

            basket.Remove("Bread", 2);
            basket.Remove("Milk", 3);
            Assert.AreEqual(0, basket.Items["Bread"]);
            Assert.AreEqual(2, basket.Items["Milk"]);
        }

        [TestMethod()]
        public void SubTotalTest()
        {
            IBasket basket = new Basket();
            string[] items = new string[] { "Bread", "Milk", "Bean", "Apple", "Bean", "Bread", "Milk" };

            basket.Add(items);

            decimal subTotal = basket.SubTotal();
            Assert.AreEqual(6.5M, subTotal);
        }
    }
}