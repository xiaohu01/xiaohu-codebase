﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ShoppingCart;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart.Tests
{
    [TestClass()]
    public class CheckOutTests
    {
        [TestMethod()]
        public void CheckOutBasketTest()
        {
            IBasket basket = new Basket();
            string[] items = new string[] { "Bread", "Milk", "Bean", "Apple", "Bean", "Bread", "Milk" };

            basket.Add(items);

            IDiscount[] discounts = new IDiscount[] { new DiscountOnApple { DiscountRate = 0.1M, OnItem = "Apple", ValidFrom = DateTime.Parse("2021-02-08"), ValidTo = DateTime.Parse("2021-02-15") }, new DiscountOnBread { DiscountRate = 0.5M, OnItem = "Bread" } };

            CheckOut checkOut = new CheckOut();
            checkOut.CheckOutBasket(basket, discounts);

            Assert.AreEqual(6.5M, checkOut.SubTotal);
            Assert.AreEqual(6.0M, checkOut.Total);
            Assert.AreEqual(2, checkOut.DiscountDescriptions.Count);
            Assert.AreEqual("Apple 10% off: 10p", checkOut.DiscountDescriptions[0]);
            Assert.AreEqual("Bread 50% off: 40p", checkOut.DiscountDescriptions[1]);
        }
    }
}