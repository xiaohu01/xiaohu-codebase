﻿using ShoppingCart;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PriceCalculator
{
    class Program
    {
        static void Main(string[] args)
        {
            IBasket basket = new Basket();

            basket.Add(args);

            CheckOut checkOut = new CheckOut();

            IDiscount[] discounts = new IDiscount[] 
            {
                new DiscountOnApple { DiscountRate = 0.1M, OnItem = "Apple", ValidFrom = DateTime.Parse("2021-02-08"), ValidTo = DateTime.Parse("2021-02-15") },
                new DiscountOnBread { DiscountRate = 0.5M, OnItem = "Bread" }
            };

            checkOut.CheckOutBasket(basket, discounts);

            checkOut.PrintCheckOut();
        }
    }
}
