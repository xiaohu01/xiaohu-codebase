﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart
{
    public interface IBasket
    {
        IDictionary<string, int> Items { get; }
        bool Add(string[] items);
        bool Remove(string item, int units);
        decimal SubTotal();
    }
}
