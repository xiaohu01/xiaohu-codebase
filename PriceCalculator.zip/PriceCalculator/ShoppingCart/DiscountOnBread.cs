﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart
{
    public class DiscountOnBread : IDiscount
    {
        public decimal DiscountRate { get; set; }

        public string OnItem { get; set; }

        public DateTime ValidFrom { get; set; }

        public DateTime ValidTo { get; set; }

        public decimal Apply(IDictionary<string, int> items)
        {
            if(items.ContainsKey("Bean") && items.ContainsKey(OnItem) && items["Bean"] >= 2)
            {
                if (items["Bean"] >= 2 * items[OnItem])
                    return items[OnItem] * 0.80M * DiscountRate; 
                else
                    return items["Bean"] / 2 * 0.80M * DiscountRate;
            }

            return default(decimal);
        }
    }
}
