﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart
{
    public class Basket : IBasket
    {
        private readonly Dictionary<string, int> _items = new Dictionary<string, int>();

        public IDictionary<string, int> Items
        {
            get
            {
                return _items;
            }
        }

        public bool Add(string[] items)
        {
            foreach(var item in items)
            {
                if(!_items.ContainsKey(item))
                    _items[item] = 1;
                else
                    _items[item] += 1;
            }

            return true;
        }

        public bool Remove(string item, int units)
        {
            if (_items[item] >= units)
            {
                _items[item] -= units;
                return true;
            }

            return false;
        }

        public decimal SubTotal()
        {
            decimal total = 0.0M;

            foreach(var item in _items)
            {
                switch (item.Key)
                {
                    case "Bean":
                        total += (decimal)(item.Value * 0.65);
                        break;
                    case "Bread":
                        total += (decimal)(item.Value * 0.80);
                        break;
                    case "Milk":
                        total += (decimal)(item.Value * 1.30);
                        break;
                    case "Apple":
                        total += (decimal)(item.Value * 1.00);
                        break;
                    default:
                        break;
                }
            }

            return total;
        }
    }
}
