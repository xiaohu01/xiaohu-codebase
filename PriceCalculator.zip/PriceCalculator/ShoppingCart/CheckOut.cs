﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart
{
    public class CheckOut
    {
        private decimal _subTotal;
        private decimal _total;
        private List<string> _discountDesc = new List<string>();

        public decimal SubTotal { get { return _subTotal; } }
        public decimal Total { get { return _total; } }
        public IList<string> DiscountDescriptions { get { return _discountDesc; } }

        public void CheckOutBasket(IBasket basket, IDiscount[] discounts)
        {
            _subTotal = basket.SubTotal();
            _total = _subTotal;

            foreach (var discount in discounts)
            {
                var disc = discount.Apply(basket.Items);
                if (disc > 0.0M)
                {
                    _discountDesc.Add($"{discount.OnItem} {(int)(discount.DiscountRate * 100)}% off: {(int)(disc * 100)}p");
                    _total -= disc; 
                }
            }
        }

        public void PrintCheckOut()
        {
            Console.WriteLine($"Subtotal: £{Math.Round(_subTotal,2)}");
            if (_discountDesc.Count > 0)
                _discountDesc.ForEach(s => Console.WriteLine(s)); 
            else
                Console.WriteLine($"(No offers available)");
            Console.WriteLine($"Total: £{Math.Round(_total,2)}");
        }
    }
}
