﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ShoppingCart
{
    public class DiscountOnApple : IDiscount
    {
        public decimal DiscountRate { get; set; }

        public string OnItem { get; set;}

        public DateTime ValidFrom { get; set; }

        public DateTime ValidTo { get; set; }

        public decimal Apply(IDictionary<string, int> items)
        {
            if(items.ContainsKey(OnItem) && DateTime.Now >= ValidFrom && DateTime.Now <= ValidTo)
            {
                return items[OnItem] * DiscountRate;
            }

            return default(decimal);
        }
    }
}
