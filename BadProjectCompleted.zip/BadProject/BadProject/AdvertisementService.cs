﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Runtime.Caching;
using System.Threading;
using ThirdParty;

namespace Adv
{
    public class AdvertisementService : IAdvertisementService
    {
        private static MemoryCache cache = new MemoryCache("");
        private static Queue<DateTime> errors = new Queue<DateTime>();

        private static object lockObj = new object();
        // **************************************************************************************************
        // Loads Advertisement information by id
        // from cache or if not possible uses the "mainProvider" or if not possible uses the "backupProvider"
        // **************************************************************************************************
        // Detailed Logic:
        // 
        // 1. Tries to use cache (and retuns the data or goes to STEP2)
        //
        // 2. If the cache is empty it uses the NoSqlDataProvider (mainProvider), 
        //    in case of an error it retries it as many times as needed based on AppSettings
        //    (returns the data if possible or goes to STEP3)
        //
        // 3. If it can't retrive the data or the ErrorCount in the last hour is more than 10, 
        //    it uses the SqlDataProvider (backupProvider)
        public Advertisement GetAdvertisement(string id)
        {
            Advertisement adv = null;

            lock (lockObj)
            {
                // Use Cache if available
                adv = (Advertisement)cache.Get($"AdvKey_{id}");

                // Count HTTP error timestamps in the last hour
                // while (errors.Count > 20) errors.Dequeue(); -- Logic doesn't specify why it needs to keep the number of queuing errors in errors no greater than 20
                
                // If the cache is empty it uses the NoSqlDataProvider
                if (adv == null)
                {
                    int retry = 0;
                    int retryCount;
                    if (!int.TryParse(ConfigurationManager.AppSettings["RetryCount"], out retryCount))
                        retryCount = 1;

                    do
                    {
                        retry++;
                        try
                        {
                            var dataProvider = new NoSqlAdvProvider();
                            adv = dataProvider.GetAdv(id);
                        }
                        catch
                        {
                            Thread.Sleep(1000);
                            errors.Enqueue(DateTime.Now); // Store HTTP error timestamp
                        }
                    } while ((adv == null) && (retry <= retryCount));


                    if (adv != null)
                    {
                        cache.Set($"AdvKey_{id}", adv, DateTimeOffset.Now.AddMinutes(5));
                    }
                }


                // If it can't retrive the data or the ErrorCount in the last hour is more than 10, it uses the SqlDataProvider (backupProvider)
                // Count HTTP error timestamps in the last hour
                int errorCount = errors.Where(e => e > DateTime.Now.AddHours(-1)).Count();

                if (adv == null || errorCount > 10)
                {
                    adv = SQLAdvProvider.GetAdv(id);

                    if (adv != null)
                    {
                        cache.Set($"AdvKey_{id}", adv, DateTimeOffset.Now.AddMinutes(5));
                    }
                }
            }
            return adv;
        }
    }
}
